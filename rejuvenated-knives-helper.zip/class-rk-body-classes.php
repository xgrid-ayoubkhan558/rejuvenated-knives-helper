<?php
/**
 * RK_Body_Classes Class - Option 2: Output Buffer
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RK_Body_Classes {

    private $cart_total = 0;

    public function __construct() {
        // Get cart total early
        add_action( 'wp', array( $this, 'init_cart_total' ) );
        
        // Add body class
        add_filter( 'body_class', array( $this, 'add_cart_body_class' ) );
        
        // Buffer output to inject attribute
        add_action( 'wp_loaded', array( $this, 'start_buffer' ) );
        add_action( 'shutdown', array( $this, 'end_buffer' ), 0 );
        
        // AJAX updates
        add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'add_fragments' ) );
        add_action( 'wp_footer', array( $this, 'ajax_update_script' ) );
    }

    /**
     * Initialize cart total
     */
    public function init_cart_total() {
        if ( function_exists( 'WC' ) && WC()->cart ) {
            $this->cart_total = floatval( WC()->cart->get_total( 'edit' ) );
        }
    }

    /**
     * Add cart class to body
     */
    public function add_cart_body_class( $classes ) {
        if ( $this->cart_total > 0 ) {
            $formatted = str_replace( '.', '', number_format( $this->cart_total, 2 ) );
            $classes[] = 'cart-total-' . $formatted;
        } else {
            $classes[] = 'cart-is-empty';
        }
        return $classes;
    }

    /**
     * Start output buffering
     */
    public function start_buffer() {
        ob_start( array( $this, 'modify_buffer' ) );
    }

    /**
     * Modify buffer to add attribute
     */
    public function modify_buffer( $buffer ) {
        $total_attr = number_format( $this->cart_total, 2, '.', '' );
        $pattern = '/<body([^>]*)>/i';
        $replacement = '<body$1 data-cart-total="' . esc_attr( $total_attr ) . '">';
        return preg_replace( $pattern, $replacement, $buffer, 1 );
    }

    /**
     * End output buffering
     */
    public function end_buffer() {
        if ( ob_get_length() ) {
            ob_end_flush();
        }
    }

    /**
     * Add cart fragments
     */
    public function add_fragments( $fragments ) {
        $total = 0;
        if ( function_exists( 'WC' ) && WC()->cart ) {
            $total = floatval( WC()->cart->get_total( 'edit' ) );
        }
        
        $fragments['rk_cart_info'] = array(
            'total' => number_format( $total, 2, '.', '' ),
            'total_class' => 'cart-total-' . str_replace( '.', '', number_format( $total, 2 ) ),
            'empty' => $total <= 0
        );
        
        return $fragments;
    }

    /**
     * AJAX update script
     */
    public function ajax_update_script() {
        ?>
        <script>
        (function($) {
            function updateBodyCartData(fragments) {
                if (!fragments.rk_cart_info) return;
                
                var info = fragments.rk_cart_info;
                var $body = $('body');
                
                // Update attribute
                $body.attr('data-cart-total', info.total);
                
                // Update class
                $body.removeClass(function(i, classes) {
                    return (classes.match(/(^|\s)cart-total-\S+/g) || []).join(' ');
                }).removeClass('cart-is-empty');
                
                if (info.empty) {
                    $body.addClass('cart-is-empty');
                } else {
                    $body.addClass(info.total_class);
                }
            }
            
            $(document.body).on('updated_wc_div wc_fragments_refreshed added_to_cart removed_from_cart', function(e, fragments) {
                updateBodyCartData(fragments || {});
            });
        })(jQuery);
        </script>
        <?php
    }
}

// new RK_Body_Classes();