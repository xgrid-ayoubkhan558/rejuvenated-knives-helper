(function () {
    'use strict';

    // ----------------------------------
    // Configuration
    // ----------------------------------
    const opts = window.rk_check_fields_options || {};
    const config = {
        enableAutoPayment: opts.enable_auto_payment == 1,
        paymentFound: opts.payment_found || 'cod',
        paymentNotFound: opts.payment_not_found || 'payment_method_stripe',
        addBodyClasses: opts.add_body_classes == 1,
        dateFormat: opts.date_format || 'd-m-Y',
        minDaysAdvance: opts.min_days_advance || 0,
        maxDaysAdvance: opts.max_days_advance || 90,
        messages: {
            mailIn: opts.mailin_message || "Good news! While your location is outside our door-to-door coverage area, you can mail in your knives using our premium mail-in service.",
            cityFound: opts.city_found_message || "Hooray! You're within our door-to-door service area.",
            citySelected: opts.city_selected_message || "Hooray! You're within our door-to-door service area."
        }
    };

    let regionsData = [];
    let cities = [];

    // ----------------------------------
    // Helpers
    // ----------------------------------
    const $ = (s, p = document) => p.querySelector(s);
    const $$ = (s, p = document) => p.querySelectorAll(s);

    function trigger(el, evt) {
        if (!el) return;
        el.dispatchEvent(new Event(evt, { bubbles: true, cancelable: true }));
    }

    function removeError(el) {
        const row = el?.closest('.form-row');
        if (!row) return;
        row.classList.remove('woocommerce-invalid', 'woocommerce-invalid-required-field');
        const err = $('.woocommerce-error', row);
        if (err) err.remove();
    }

    // ----------------------------------
    // Data
    // ----------------------------------
    function buildCitiesList() {
        cities = [];
        regionsData.forEach(region => {
            (region.cities || []).forEach(city => {
                cities.push({ ...city, region });
            });
        });
    }

    function loadData() {
        const holder = document.getElementById('rk-check-fields-data');
        if (holder?.dataset?.regions) {
            try {
                regionsData = JSON.parse(holder.dataset.regions);
                buildCitiesList();
            } catch (e) {
                console.error('[RK] Invalid regions JSON', e);
            }
        }
    }

    // ----------------------------------
    // Body classes
    // ----------------------------------
    function updateBodyClass(hasCity, state = null) {
        if (!config.addBodyClasses) return;

        document.body.classList.remove(
            'rk-city-selected',
            'rk-city-not-selected',
            'rk-city-found',
            'rk-city-not-found'
        );

        document.body.classList.add(hasCity ? 'rk-city-selected' : 'rk-city-not-selected');

        if (state) document.body.classList.add(`rk-city-${state}`);

        if (state === 'found' || hasCity) {
            document.body.setAttribute('data-payment-method', config.paymentFound);
        } else if (state === 'not-found') {
            document.body.setAttribute('data-payment-method', config.paymentNotFound);
        } else {
            document.body.removeAttribute('data-payment-method');
        }
    }

    function selectPaymentMethod(id) {
        const method = $(`input[name="payment_method"][value="${id}"]`);
        if (method) {
            method.checked = true;
            trigger(method, 'change');
        }
    }

    // ----------------------------------
    // Date picker
    // ----------------------------------
    function initDatePicker(input, region) {
        if (!input || typeof flatpickr === 'undefined') return null;

        const enabledDays = [];
        if (region.pickup) {
            Object.values(region.pickup).forEach((day, i) => {
                if (day?.enabled) enabledDays.push(i);
            });
        }

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return flatpickr(input, {
            dateFormat: config.dateFormat,
            minDate: new Date(today.getTime() + config.minDaysAdvance * 86400000),
            maxDate: config.maxDaysAdvance > 0
                ? new Date(today.getTime() + config.maxDaysAdvance * 86400000)
                : null,
            disable: enabledDays.length
                ? [date => !enabledDays.includes(date.getDay())]
                : []
        });
    }

    // ----------------------------------
    // City search
    // ----------------------------------
    function initCitySearch() {
        const searchInput = $('#billing_rk_city_search');
        const cityInput = $('#billing_rk_city');
        const regionInput = $('#billing_rk_region');
        const dateInput = $('#billing_rk_pickup_date');

        if (!searchInput || !cityInput) return;

        if (regionInput) {
            regionInput.readOnly = true;
            regionInput.style.cssText = 'background:#f5f5f5;cursor:not-allowed;';
        }

        const wrapper = document.createElement('div');
        wrapper.className = 'rk-city-wrapper';
        searchInput.after(wrapper);

        const dropdown = document.createElement('div');
        dropdown.className = 'rk-city-dropdown';
        wrapper.appendChild(dropdown);

        const message = document.createElement('div');
        message.className = 'rk-message';
        wrapper.appendChild(message);

        let datePicker = null;
        const dateRow = dateInput?.closest('.form-row');
        if (dateRow) dateRow.style.display = 'none';

        function selectCity(city) {
            searchInput.value = city.city_name;
            cityInput.value = city.city_name;
            if (regionInput) regionInput.value = city.region.region_name;

            trigger(cityInput, 'change');
            if (regionInput) trigger(regionInput, 'change');

            dropdown.style.display = 'none';
            message.textContent = config.messages.citySelected;

            updateBodyClass(true, 'selected');

            if (config.enableAutoPayment) {
                selectPaymentMethod(config.paymentFound);
            }

            if (dateInput) {
                if (datePicker) datePicker.destroy();
                datePicker = initDatePicker(dateInput, city.region);
                if (dateRow) dateRow.style.display = '';
                dateInput.required = true;
            }

            const btn = $('#place_order');
            if (btn) btn.disabled = false;
        }

        searchInput.addEventListener('input', function () {
            const q = this.value.toLowerCase().trim();
            dropdown.innerHTML = '';

            if (!q) return;

            const matches = cities.filter(c =>
                `${c.city_name} ${c.region.region_name}`.toLowerCase().includes(q)
            );

            if (!matches.length) {
                message.textContent = config.messages.mailIn;
                updateBodyClass(false, 'not-found');
                if (config.enableAutoPayment) {
                    selectPaymentMethod(config.paymentNotFound);
                }
                return;
            }

            message.textContent = config.messages.cityFound;
            updateBodyClass(false, 'found');
            dropdown.style.display = 'block';

            matches.forEach(city => {
                const opt = document.createElement('div');
                opt.className = 'rk-city-option';
                opt.textContent = `${city.city_name} (${city.region.region_name})`;
                opt.onclick = () => selectCity(city);
                dropdown.appendChild(opt);
            });
        });

        // ----------------------------------
        // 🔥 PREFILLED FIELD FIX
        // ----------------------------------
        setTimeout(() => {
            if (searchInput.value) trigger(searchInput, 'input');
            if (cityInput.value) trigger(cityInput, 'change');
        }, 150);
    }

    // ----------------------------------
    // Init
    // ----------------------------------
    function init() {
        loadData();
        if (regionsData.length) initCitySearch();
    }

    document.readyState === 'loading'
        ? document.addEventListener('DOMContentLoaded', init)
        : init();

    // Woo updates
    if (window.jQuery) {
        jQuery(document.body).on('updated_checkout', () => {
            setTimeout(() => {
                const input = document.getElementById('billing_rk_city_search');
                if (input?.value) {
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }, 150);
        });
    }

})();
